$JAVA_HOME/bin/java com.dcfs.rsm.client.SendMonData $1 $2 
