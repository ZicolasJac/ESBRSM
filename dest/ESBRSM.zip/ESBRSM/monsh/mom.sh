$JAVA_HOME/bin/java com.dcfs.rsm.mom.MomCollector $1 $mom_url
